#pragma once
#include <time.h>
bool setupRTC();
bool getLocalTime(struct tm *info);
