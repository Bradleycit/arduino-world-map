The smooth library and WorldClock.ino were written by Eric Woolsey. Other included libraries were not and I do not take credit for them.

Place WorldClock into Documents/Arduino/

Place items inside Arduino\ Libraries into Documents/Arduino/libraries
	if hardware does not exist then create it

If you would like to run off the 8MHz internal clock then please lookup the tutorial online. This code will work fine on a regular arduino.